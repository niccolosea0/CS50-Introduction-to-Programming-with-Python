import re


def main():
    code = input("Hexadecimal color code: ")
    ...


main()
