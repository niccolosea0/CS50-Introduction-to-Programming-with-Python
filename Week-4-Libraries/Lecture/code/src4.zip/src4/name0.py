# Demonstrates sys.argv

import sys

print("hello, my name is", sys.argv[1])
