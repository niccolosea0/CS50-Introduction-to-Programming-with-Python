# Demonstrates import and random.choice

import random

coin = random.choice(["heads", "tails"])
print(coin)
