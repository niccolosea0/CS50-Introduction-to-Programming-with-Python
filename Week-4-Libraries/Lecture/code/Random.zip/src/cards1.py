import random

cards = ["jack", "queen", "king"]


def main():
    print(random.choice(cards))


main()
