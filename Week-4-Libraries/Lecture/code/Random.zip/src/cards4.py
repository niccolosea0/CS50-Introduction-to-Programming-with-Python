import random

cards = ["jack", "queen", "king"]


def main():
    print(random.sample(cards, k=2))


main()
