cards = ["jack", "queen", "king"]


def main(): ...


main()
