# Prints the type of an integer

print(type(50))
