# Prints the type of a dictionary

print(type(dict()))
