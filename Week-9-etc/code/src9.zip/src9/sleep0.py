# Prints n sheep

n = int(input("What's n? "))
for i in range(n):
    print("🐑" * i)
