# Prints column of bricks using a function with a loop


def main():
    print_column(3)


def print_column(height):
    for _ in range(height):
        print("#")


main()
