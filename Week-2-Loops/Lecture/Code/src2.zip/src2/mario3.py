# Prints column of bricks using a function with str multiplication


def main():
    print_column(3)


def print_column(height):
    print("#\n" * height, end="")


main()
