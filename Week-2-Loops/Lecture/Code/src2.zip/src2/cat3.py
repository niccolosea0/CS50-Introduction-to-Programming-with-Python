# Demonstrates a while loop, counting up from 0

i = 0
while i < 3:
    print("meow")
    i = i + 1
