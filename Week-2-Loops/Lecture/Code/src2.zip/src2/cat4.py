# Demonstrates (more succinct) incrementation

i = 0
while i < 3:
    print("meow")
    i += 1
