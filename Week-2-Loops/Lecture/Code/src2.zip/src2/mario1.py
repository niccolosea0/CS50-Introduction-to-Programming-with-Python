# Prints column of bricks using a loop

for _ in range(3):
    print("#")
