# Demonstrates a for loop, using a list

for i in [0, 1, 2]:
    print("meow")
