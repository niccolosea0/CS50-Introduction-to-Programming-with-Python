# Demonstrates a while loop, counting down

i = 3
while i != 0:
    print("meow")
    i = i - 1
