# Demonstrates multiple (identical) function calls

print("meow")
print("meow")
print("meow")
